import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fab_circular_menu_plus/fab_circular_menu_plus.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:math';

import 'package:flutter_application_1/event_model.dart';

class MyHome extends StatefulWidget {
  const MyHome({Key? key}) : super(key: key);

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  List<EventModel> details = [];

  @override
  void initState() {
    readData();
    super.initState();
  }

  Future testData() async {
    await Firebase.initializeApp();
    print('init Done');
    FirebaseFirestore db = await FirebaseFirestore.instance;
    print('init Firestore Done');

    var data = await db.collection('event_detail').get().then((event) {
      for (var doc in event.docs) {
        print('${doc.id} => ${doc.data()}');
      }
    });
  }

  Future readData() async {
    await Firebase.initializeApp();
    FirebaseFirestore db = await FirebaseFirestore.instance;
    var data = await db.collection('event_detail').get();
    setState(() {
      details =
          data.docs.map((doc) => EventModel.fromDocSnapshot(doc)).toList();
    });
  }

  addRand() async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    EventModel InsertData = EventModel(
      judul: getRandString(5),
      keterangan: getRandString(30),
      tanggal: getRandString(10),
      is_like: Random().nextBool(),
      pembicara: getRandString(20),
    );
    await db.collection('event_detail').add(InsertData.toMap());
    setState(() {
      details.add(InsertData);
    });
  }

  String getRandString(int len) {
    var random = Random.secure();
    var values = List<int>.generate(len, (i) => random.nextInt(255));
    return base64UrlEncode(values);
  }

  deleteLast(String documentId) async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    await db.collection("event_detail").doc(documentId).delete();
    setState(() {
      details.removeLast();
    });
  }

  updateEvent(int pos) async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    await db
        .collection('event_detail')
        .doc(details[pos].id)
        .update({'is_like': !details[pos].is_like});
    setState(() {
      details[pos].is_like = !details[pos].is_like;
    });
  }

  Future<void> showUpdateDialog(EventModel eventData) async {
    TextEditingController judulController =
        TextEditingController(text: eventData.judul);
    TextEditingController keteranganController =
        TextEditingController(text: eventData.keterangan);
    TextEditingController tanggalController =
        TextEditingController(text: eventData.tanggal);
    TextEditingController pembicaraController =
        TextEditingController(text: eventData.pembicara);

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Update Data'),
          content: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                TextField(
                  controller: judulController,
                  decoration: InputDecoration(labelText: 'Judul'),
                ),
                TextField(
                  controller: keteranganController,
                  decoration: InputDecoration(labelText: 'Keterangan'),
                ),
                TextField(
                  controller: tanggalController,
                  decoration: InputDecoration(labelText: 'Tanggal'),
                ),
                TextField(
                  controller: pembicaraController,
                  decoration: InputDecoration(labelText: 'Pembicara'),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Batal'),
            ),
            TextButton(
              onPressed: () {
                // Implement logic untuk memperbarui data di Firebase
                // Anda bisa menggunakan controller.text untuk mendapatkan nilai dari setiap TextField
                updateDataInFirebase(
                  eventData.id,
                  judulController.text,
                  keteranganController.text,
                  tanggalController.text,
                  pembicaraController.text,
                );
                Navigator.of(context).pop();
              },
              child: Text('Update'),
            ),
          ],
        );
      },
    );
  }

  Future<void> showAddDialog() async {
    TextEditingController judulController = TextEditingController();
    TextEditingController keteranganController = TextEditingController();
    TextEditingController tanggalController = TextEditingController();
    TextEditingController pembicaraController = TextEditingController();

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Tambah Data'),
          content: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                TextField(
                  controller: judulController,
                  decoration: InputDecoration(labelText: 'Judul'),
                ),
                TextField(
                  controller: keteranganController,
                  decoration: InputDecoration(labelText: 'Keterangan'),
                ),
                TextField(
                  controller: tanggalController,
                  decoration: InputDecoration(labelText: 'Tanggal'),
                ),
                TextField(
                  controller: pembicaraController,
                  decoration: InputDecoration(labelText: 'Pembicara'),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Batal'),
            ),
            TextButton(
              onPressed: () {
                // Implement logic untuk menambahkan data di Firebase
                addDataToFirebase(
                  judulController.text,
                  keteranganController.text,
                  tanggalController.text,
                  pembicaraController.text,
                );
                Navigator.of(context).pop();
              },
              child: Text('Tambah'),
            ),
          ],
        );
      },
    );
  }

  Future<void> updateDataInFirebase(
      String? documentId,
      String judul,
      String keterangan,
      String tanggal,
      String pembicara,
      ) async {
    if (documentId != null) {
      FirebaseFirestore db = await FirebaseFirestore.instance;
      await db.collection("event_detail").doc(documentId).update({
        'judul': judul,
        'keterangan': keterangan,
        'tanggal': tanggal,
        'pembicara': pembicara,
      });

      setState(() {
        int index = details.indexWhere((element) => element.id == documentId);
        details[index] = EventModel(
          id: documentId,
          judul: judul,
          keterangan: keterangan,
          tanggal: tanggal,
          is_like: details[index].is_like,
          pembicara: pembicara,
        );
      });
    }
  }

  Future<void> addDataToFirebase(
      String judul, String keterangan, String tanggal, String pembicara) async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    EventModel InsertData = EventModel(
      judul: judul,
      keterangan: keterangan,
      tanggal: tanggal,
      is_like: false, // Default value for is_like
      pembicara: pembicara,
    );
    await db.collection('event_detail').add(InsertData.toMap());
    setState(() {
      details.add(InsertData);
    });
  }

  @override
  Widget build(BuildContext context) {
    // testData();
    return Scaffold(
      appBar: AppBar(title: Text("Cloud Firebase")),
      body: ListView.builder(
        itemCount: details.length,
        itemBuilder: (context, position) {
          return Card(
            child: ListTile(
              title: Text(details[position].judul),
              subtitle: Text(
                '${details[position].keterangan}\nHari: ${details[position].tanggal}\nPembicara: ${details[position].pembicara}',
              ),
              isThreeLine: true,
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () {
                      // Implement your update logic here
                      showUpdateDialog(details[position]);
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () {
                      // Implement your delete logic here
                      deleteLast(details[position].id!);
                    },
                  ),
                ],
              ),
              onTap: () {
                // Implement your custom action on item tap
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Implement logic untuk menampilkan dialog tambah data
          showAddDialog();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
